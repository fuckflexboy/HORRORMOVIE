package com.homehorror.tv.util

import android.content.Context
import com.google.gson.Gson
import com.homehorror.tv.model.VideoFeed
import java.io.*

class CacheManager(private val context: Context) {
    companion object {
        private const val CACHE_FILE = "video_feed_cache.json"
        private const val CACHE_EXPIRY_HOURS = 24L
    }

    fun saveFeedToCache(feed: VideoFeed) {
        try {
            val json = Gson().toJson(feed)
            context.openFileOutput(CACHE_FILE, Context.MODE_PRIVATE).use { stream ->
                stream.write(json.toByteArray())
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun loadFeedFromCache(): VideoFeed? {
        try {
            val file = File(context.filesDir, CACHE_FILE)
            if (!file.exists() || isCacheExpired(file)) {
                return null
            }

            context.openFileInput(CACHE_FILE).use { stream ->
                val json = stream.bufferedReader().use { it.readText() }
                return Gson().fromJson(json, VideoFeed::class.java)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }

    private fun isCacheExpired(file: File): Boolean {
        val lastModified = file.lastModified()
        val currentTime = System.currentTimeMillis()
        val expiryTime = CACHE_EXPIRY_HOURS * 60 * 60 * 1000 // Convert hours to milliseconds
        return (currentTime - lastModified) > expiryTime
    }

    fun clearCache() {
        try {
            val file = File(context.filesDir, CACHE_FILE)
            if (file.exists()) {
                file.delete()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
} 