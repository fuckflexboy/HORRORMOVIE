package com.homehorror.tv.ui

import android.app.Activity
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.leanback.app.BackgroundManager
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.homehorror.tv.R
import java.util.Timer
import java.util.TimerTask

class CustomBackgroundManager(private val activity: Activity) {
    private val backgroundManager: BackgroundManager = BackgroundManager.getInstance(activity)
    private val metrics: DisplayMetrics = DisplayMetrics()
    private var defaultBackground: Drawable? = null
    private var backgroundTimer: Timer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var currentBackground: Drawable? = null

    init {
        backgroundManager.attach(activity.window)
        activity.windowManager.defaultDisplay.getMetrics(metrics)
        defaultBackground = ContextCompat.getDrawable(activity, R.drawable.default_background)
        setDefaultBackground()
    }

    fun loadBackground(url: String) {
        cancelTimer()
        backgroundTimer = Timer()
        backgroundTimer?.schedule(object : TimerTask() {
            override fun run() {
                handler.post {
                    if (activity.isDestroyed) return@post
                    updateBackground(url)
                }
            }
        }, BACKGROUND_UPDATE_DELAY.toLong())
    }

    private fun updateBackground(url: String) {
        Glide.with(activity)
            .load(url)
            .centerCrop()
            .error(defaultBackground)
            .into(object : CustomTarget<Drawable>() {
                override fun onResourceReady(
                    resource: Drawable,
                    transition: Transition<in Drawable>?
                ) {
                    currentBackground = resource
                    backgroundManager.drawable = resource
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    backgroundManager.drawable = defaultBackground
                }
            })
    }

    private fun setDefaultBackground() {
        backgroundManager.drawable = defaultBackground
    }

    fun clearBackground() {
        cancelTimer()
        backgroundManager.drawable = defaultBackground
    }

    private fun cancelTimer() {
        backgroundTimer?.cancel()
        backgroundTimer = null
    }

    companion object {
        private const val BACKGROUND_UPDATE_DELAY = 300
    }
} 