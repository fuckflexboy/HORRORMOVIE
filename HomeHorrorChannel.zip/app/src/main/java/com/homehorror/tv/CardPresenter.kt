package com.homehorror.tv

import android.graphics.drawable.Drawable
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.core.content.ContextCompat
import androidx.leanback.widget.ImageCardView
import androidx.leanback.widget.Presenter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition
import com.homehorror.tv.model.Video

class CardPresenter : Presenter() {
    private var defaultCardImage: Drawable? = null
    private var selectedBackgroundColor: Int = 0
    private var defaultBackgroundColor: Int = 0

    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        defaultBackgroundColor = ContextCompat.getColor(parent.context, R.color.card_background)
        selectedBackgroundColor = ContextCompat.getColor(parent.context, R.color.card_selected)
        defaultCardImage = ContextCompat.getDrawable(parent.context, R.drawable.default_background)

        val cardView = ImageCardView(parent.context).apply {
            isFocusable = true
            isFocusableInTouchMode = true
            setMainImageDimensions(CARD_WIDTH, CARD_HEIGHT)
            setMainImageScaleType(android.widget.ImageView.ScaleType.CENTER_CROP)
            setBackgroundColor(defaultBackgroundColor)
            setInfoAreaBackgroundColor(defaultBackgroundColor)
        }

        return ViewHolder(cardView)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, item: Any) {
        val video = item as Video
        val cardView = viewHolder.view as ImageCardView

        cardView.titleText = video.title
        cardView.contentText = video.shortDescription

        cardView.setMainImageDimensions(CARD_WIDTH, CARD_HEIGHT)
        
        // Load thumbnail with animation
        Glide.with(cardView.context)
            .load(video.thumbnail)
            .transition(DrawableTransitionOptions.withCrossFade())
            .centerCrop()
            .error(defaultCardImage)
            .into(object : CustomTarget<Drawable>() {
                override fun onResourceReady(
                    resource: Drawable,
                    transition: Transition<in Drawable>?
                ) {
                    cardView.mainImage = resource
                    cardView.mainImageView.startAnimation(
                        AnimationUtils.loadAnimation(cardView.context, R.anim.fade_in)
                    )
                }

                override fun onLoadCleared(placeholder: Drawable?) {
                    cardView.mainImage = defaultCardImage
                }
            })

        // Add focus animation
        cardView.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                cardView.setBackgroundColor(selectedBackgroundColor)
                cardView.setInfoAreaBackgroundColor(selectedBackgroundColor)
                cardView.startAnimation(
                    AnimationUtils.loadAnimation(cardView.context, R.anim.scale_up)
                )
            } else {
                cardView.setBackgroundColor(defaultBackgroundColor)
                cardView.setInfoAreaBackgroundColor(defaultBackgroundColor)
                cardView.startAnimation(
                    AnimationUtils.loadAnimation(cardView.context, R.anim.scale_down)
                )
            }
        }
    }

    override fun onUnbindViewHolder(viewHolder: ViewHolder) {
        val cardView = viewHolder.view as ImageCardView
        cardView.mainImage = null
    }

    companion object {
        private const val CARD_WIDTH = 313
        private const val CARD_HEIGHT = 176
    }
} 