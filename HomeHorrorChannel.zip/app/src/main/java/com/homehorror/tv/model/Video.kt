package com.homehorror.tv.model

data class Video(
    val id: String,
    val title: String,
    val content: VideoContent,
    val thumbnail: String,
    val shortDescription: String,
    val genres: List<String>
)

data class VideoContent(
    val dateAdded: String,
    val captions: List<String>,
    val duration: Int,
    val videos: List<VideoSource>
)

data class VideoSource(
    val url: String,
    val quality: String,
    val videoType: String
)

data class VideoFeed(
    val providerName: String,
    val language: String,
    val lastUpdated: String,
    val shortFormVideos: List<Video>
) 