package com.homehorror.tv

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.core.content.ContextCompat
import androidx.leanback.app.BrowseSupportFragment
import androidx.leanback.widget.*
import com.google.gson.Gson
import com.homehorror.tv.model.Video
import com.homehorror.tv.model.VideoFeed
import com.homehorror.tv.ui.CustomBackgroundManager
import com.homehorror.tv.ui.ErrorDialogFragment
import com.homehorror.tv.util.CacheManager
import kotlinx.coroutines.*
import java.net.URL
import java.net.UnknownHostException
import javax.net.ssl.HttpsURLConnection

class MainBrowseFragment : BrowseSupportFragment() {

    private lateinit var videoFeed: VideoFeed
    private lateinit var backgroundManager: CustomBackgroundManager
    private lateinit var cacheManager: CacheManager
    private val coroutineScope = CoroutineScope(Dispatchers.Main + Job())

    companion object {
        private const val CDN_BASE_URL = "http://localhost:3000"
        private const val FEED_ENDPOINT = "$CDN_BASE_URL/api/feed"
        private const val GENRES_ENDPOINT = "$CDN_BASE_URL/api/genres"
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        backgroundManager = CustomBackgroundManager(requireActivity())
        cacheManager = CacheManager(requireContext())

        setupUIElements()
        loadContent()
        setupEventListeners()
    }

    private fun loadContent() {
        // First try to load from cache
        cacheManager.loadFeedFromCache()?.let {
            videoFeed = it
            loadRows()
            // Refresh in background
            loadDataFromCDN(isRefresh = true)
            return
        }

        // If no cache, load from CDN
        loadDataFromCDN(isRefresh = false)
    }

    private fun loadDataFromCDN(isRefresh: Boolean) {
        coroutineScope.launch {
            try {
                val jsonString = withContext(Dispatchers.IO) {
                    URL(FEED_ENDPOINT).openStream().bufferedReader().use { it.readText() }
                }
                videoFeed = Gson().fromJson(jsonString, VideoFeed::class.java)
                
                // Save to cache
                cacheManager.saveFeedToCache(videoFeed)
                
                if (!isRefresh) {
                    loadRows()
                }
            } catch (e: Exception) {
                if (!isRefresh) {
                    handleError(e)
                }
            }
        }
    }

    private fun handleError(error: Exception) {
        val errorMessage = when (error) {
            is UnknownHostException -> getString(R.string.error_network)
            else -> getString(R.string.error_loading)
        }

        ErrorDialogFragment.newInstance(errorMessage) {
            loadDataFromCDN(isRefresh = false)
        }.show(childFragmentManager, "error")
    }

    private fun setupUIElements() {
        title = getString(R.string.browse_title)
        
        // Set fastLane (header) background color
        brandColor = ContextCompat.getColor(requireContext(), R.color.fastlane_background)
        
        // Set search icon color
        searchAffordanceColor = ContextCompat.getColor(requireContext(), R.color.search_opaque)
        
        // Set headers state for the row fragment
        headersState = HEADERS_ENABLED
        isHeadersTransitionOnBackEnabled = true

        // Set fade details row for smooth transition
        setHeaderPresenterSelector(object : PresenterSelector() {
            override fun getPresenter(item: Any?): Presenter {
                return HeaderItemPresenter()
            }
        })

        // Enable transitions
        enableMainFragmentScaling(true)
    }

    private fun loadRows() {
        val rowsAdapter = ArrayObjectAdapter(ListRowPresenter(FocusHighlight.ZOOM_FACTOR_LARGE))
        val cardPresenter = CardPresenter()

        // Featured row
        val featuredHeader = HeaderItem(0, getString(R.string.featured))
        val featuredRow = ArrayObjectAdapter(cardPresenter)
        videoFeed.shortFormVideos.take(5).forEach { featuredRow.add(it) }
        rowsAdapter.add(ListRow(featuredHeader, featuredRow))

        // Recently Added
        val recentHeader = HeaderItem(1, getString(R.string.recently_added))
        val recentRow = ArrayObjectAdapter(cardPresenter)
        videoFeed.shortFormVideos.sortedByDescending { it.content.dateAdded }.take(15)
            .forEach { recentRow.add(it) }
        rowsAdapter.add(ListRow(recentHeader, recentRow))

        // Create genre-based rows
        var id = 2L
        videoFeed.shortFormVideos.flatMap { it.genres }.distinct().forEach { genre ->
            val genreVideos = ArrayObjectAdapter(cardPresenter)
            videoFeed.shortFormVideos.filter { it.genres.contains(genre) }
                .forEach { genreVideos.add(it) }
            val header = HeaderItem(id, genre.capitalize())
            rowsAdapter.add(ListRow(header, genreVideos))
            id++
        }

        adapter = rowsAdapter
    }

    private fun setupEventListeners() {
        onItemViewClickedListener = OnItemViewClickedListener { itemViewHolder, item, rowViewHolder, row ->
            if (item is Video) {
                val intent = Intent(activity, PlayerActivity::class.java)
                intent.putExtra(PlayerActivity.VIDEO_ID, item.id)
                intent.putExtra(PlayerActivity.VIDEO_URL, item.content.videos[0].url)
                intent.putExtra(PlayerActivity.VIDEO_TITLE, item.title)
                startActivity(intent)
            }
        }

        onItemViewSelectedListener = OnItemViewSelectedListener { itemViewHolder, item, rowViewHolder, row ->
            if (item is Video) {
                backgroundManager.loadBackground(item.thumbnail)
            }
        }

        setOnSearchClickedListener {
            // TODO: Implement search functionality using CDN search endpoint
        }
    }

    override fun onDestroy() {
        backgroundManager.clearBackground()
        coroutineScope.cancel()
        super.onDestroy()
    }
}

class HeaderItemPresenter : Presenter() {
    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val view = TextView(parent.context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setTextColor(ContextCompat.getColor(context, R.color.browse_title_color))
            textSize = 16f
        }
        return ViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, item: Any) {
        val headerItem = item as HeaderItem
        (viewHolder.view as TextView).text = headerItem.name
    }

    override fun onUnbindViewHolder(viewHolder: ViewHolder) {
        // Nothing to do here
    }
} 