package com.homehorror.tv.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import com.homehorror.tv.R

class ErrorDialogFragment : DialogFragment() {
    private var errorMessage: String? = null
    private var retryAction: (() -> Unit)? = null

    companion object {
        fun newInstance(message: String, retry: () -> Unit): ErrorDialogFragment {
            return ErrorDialogFragment().apply {
                errorMessage = message
                retryAction = retry
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_error_dialog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<TextView>(R.id.error_message).text = errorMessage
        
        view.findViewById<Button>(R.id.retry_button).setOnClickListener {
            dismiss()
            retryAction?.invoke()
        }
        
        view.findViewById<Button>(R.id.close_button).setOnClickListener {
            dismiss()
        }
    }
} 