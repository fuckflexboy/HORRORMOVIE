# Home Horror Channel - Android TV Horror Streaming App

A streaming application for Android TV that provides access to a collection of public domain horror movies.

## Setup Instructions

1. Clone the repository
2. Open the project in Android Studio
3. Place the `horrortheque_feed_full_150.json` file in the `app/src/main/assets` folder
4. Sync the project with Gradle files
5. Build and run the app on an Android TV device or emulator

## Requirements

- Android Studio Arctic Fox or newer
- Android TV device or emulator running Android 5.0 (API 21) or higher
- Internet connection for streaming video content

## Features

- Browse horror movies in a Netflix-style interface
- Stream public domain horror movies
- Categories and genres organization
- Video player with custom controls
- Dynamic background changes
- Smooth animations and transitions

## Project Structure

- `app/src/main/java/com/homehorror/tv/`
  - `MainActivity.kt` - Main activity for browsing content
  - `MainBrowseFragment.kt` - Browse fragment for content display
  - `PlayerActivity.kt` - Video player activity
  - `CardPresenter.kt` - Presenter for video cards
  - `model/` - Data models
  - `ui/` - UI components

## Dependencies

- AndroidX Leanback
- ExoPlayer (Media3)
- Glide
- Gson

## License

This project is licensed under the MIT License.